﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class steamIn : MonoBehaviour
{
    // Start is called before the first frame update
    private float steamInput=0;
	private float a=100;
	private float b=220;
	private float c=250;
	private float d=250;
	public void OnSteamIn() // this function is called when valve is rotated 
	{
        if(ExampleUModbusTCP.val[0]==1)
			steamInput=150;
        else if(ExampleUModbusTCP.val[1] == 0)
            steamInput = 0;

    }
	public float GetSteamTemp(){
		return steamInput;
	} 
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void FixedUpdate()
    {

        InvokeRepeating("OnSteamIn", 1f, 2.5f);
    }
}
