﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using DG.Tweening;
public class waterInput : MonoBehaviour
{
    public GameObject initialTemprature;
    public GameObject finalTemprature;
    public GameObject CubeMover;
    //public CubeMover cm=GameObject.GetComponent<CubeMover>();
    public TextMeshPro tempC;
    private float expectedWaterOutTemp = 0, waterOut = 0, waterIn = 0;
    private float TDC = 1.5435f, steamTemp = 0, temp=0;
    private float a = 100, b = 200, c = 1150, d = 600;
    private bool check = false;
    private bool Inc = false;
    private bool Dec = false;
   // ExampleUModbusTCP m_oUModbusTCP;
    public void Running()
    {
        if (ExampleUModbusTCP.val[4] == 0)
            CancelInvoke("Running");
        else
        {
            GameObject.FindGameObjectWithTag("leak").transform.position = new Vector3(2.2f, -0.28f, 12.45f);
            CancelInvoke("Running");
        }
    }
    public void Stopping() { // stopping increment e.g pausing the screen
        CancelInvoke("Increment");
    }
	void OnGUI() // GUI TEXT Showing different information
	{
        GUIStyle style = new GUIStyle();
        style.fontStyle = FontStyle.Bold;
        style.fontSize = 20;
        style.richText = true;
        style.normal.textColor = Color.white;
        style.alignment = TextAnchor.MiddleCenter;
		GUI.Label(new Rect(a,b,c,d),"Water's Expected Temperature is "+(ExampleUModbusTCP.val[1]).ToString() + "°C", style);
		GUI.Label(new Rect(a, b + 25, c, d),"Steam's Input Pressure is "+((int)steamTemp).ToString()+" pa", style);
        GUI.Label(new Rect(a, b + 50, c, d), "Water's Final Temperature is " + (ExampleUModbusTCP.val[3]).ToString() + "°C", style);
	}
    // Start is called before the first frame update
    void Start()
    {
        GameObject.FindGameObjectWithTag("leak").transform.position = new Vector3(0f, -300f, 0f);
        tempC.text = "0 °C";
    }

    // Update is called once per frame
    void Update()
    {
        TempChange();
        tempC.text = (ExampleUModbusTCP.val[3]).ToString() + "°C";
        Increment();
    }
	void Increment(){
        if (ExampleUModbusTCP.val[4]==1)
        {
            InvokeRepeating("Running", 20f, 1f);
        }
	}	
	void TempChange(){
		steamTemp=GameObject.FindGameObjectWithTag("outerTank").GetComponent<steamIn>().GetSteamTemp();
	}
}
