﻿using UnityEngine;
using UnityEngine.UI;
using System;

using System.Collections;
public class ExampleUModbusTCP : MonoBehaviour {

    //Public vars
    /*public InputField inputIP;
    public InputField inputPort;
    public InputField inputAddress;
    public InputField inputResponseValue;
    */
    //Private vars
    //UModbusTCP
    UModbusTCP m_oUModbusTCP;
    UModbusTCP.ResponseData m_oUModbusTCPResponse;
    UModbusTCP.ExceptionData m_oUModbusTCPException;

    bool m_bUpdateResponse;
    int m_iResponseValue;
    public static int[] val = new int[10];
    public static int[] coils = new int[2];

    void Awake() {
        //UModbusTCP
        m_oUModbusTCP = null;
        m_oUModbusTCPResponse = null;
        m_oUModbusTCPException = null;
        m_bUpdateResponse = false;
        m_iResponseValue = -1;

        for (int i = 0; i < 10; i++)
            val[i] = 0;
        m_oUModbusTCP = UModbusTCP.Instance;
    }

    void Start() {
        //Fast values
        /* inputIP.text = "127.0.0.1";
         inputPort.text = "502";
         inputAddress.text = "1";
         */

      //  InvokeRepeating("GetData", 2f, 2f);
       // InvokeRepeating("GetHoldingData", 2f, 2f);
    }


    void FixedUpdate() {

        StartCoroutine(GetHoldingData());
    }
    IEnumerator GetHoldingData()
    {
        if (!m_oUModbusTCP.connected)
        {
            m_oUModbusTCP.Connect("127.0.0.1", 502);
        }

        if (m_oUModbusTCPResponse != null)
        {
            m_oUModbusTCP.OnResponseData -= m_oUModbusTCPResponse;
        }
        m_oUModbusTCPResponse = new UModbusTCP.ResponseData(UModbusTCPOnResponseData);
        m_oUModbusTCP.OnResponseData += m_oUModbusTCPResponse;

        //Exception callback
        if (m_oUModbusTCPException != null)
        {
            m_oUModbusTCP.OnException -= m_oUModbusTCPException;
        }
        m_oUModbusTCPException = new UModbusTCP.ExceptionData(UModbusTCPOnException);
        m_oUModbusTCP.OnException += m_oUModbusTCPException;
        /*for (ushort i = 1; i < 10; i++) {

            m_oUModbusTCP.ReadHoldingRegister(2, 1, i, 1);
            val[i - 1] = m_iResponseValue;
            
        }*/
        m_oUModbusTCP.ReadHoldingRegister(2, 1, 0, 1);
        val[0] = m_iResponseValue;
        Debug.Log("HoldingData: " + 0 + "  " + m_iResponseValue);
        yield return new WaitForSeconds(3f);
        m_oUModbusTCP.ReadHoldingRegister(2, 1, 1, 1);
        val[1] = m_iResponseValue;
        Debug.Log("HoldingData: " + 1 + "  " + m_iResponseValue);
        yield return new WaitForSeconds(3f);
        m_oUModbusTCP.ReadHoldingRegister(2, 1, 2, 1);
        val[2] = m_iResponseValue;
        Debug.Log("HoldingData: " + 2 + "  " + m_iResponseValue);
        yield return new WaitForSeconds(3f);
        m_oUModbusTCP.ReadHoldingRegister(2, 1, 3, 1);
        val[3] = m_iResponseValue;
        Debug.Log("HoldingData: " + 3 + "  " + m_iResponseValue);
        yield return new WaitForSeconds(3f);
        m_oUModbusTCP.ReadHoldingRegister(2, 1, 4, 1);
        val[4] = m_iResponseValue;
        Debug.Log("HoldingData: " + 4 + "  " + m_iResponseValue);
        yield return new WaitForSeconds(3f);
        // for (int j = 0; j < 10; j++) { 
        //     Debug.Log("HoldingData: " + j + "  " + val[j]);
        //}
    }


    void UModbusTCPOnResponseData(ushort _oID, byte _oUnit, byte _oFunction, byte[] _oValues) {

        //Number of values
        int iNumberOfValues = _oValues[8];
      
        byte[] oResponseFinalValues = new byte[iNumberOfValues];
        for(int i = 0; i < iNumberOfValues; ++i) {
            oResponseFinalValues[i] = _oValues[9 + i];
        }

        int[] iValues = UModbusTCPHelpers.GetIntsOfBytes(oResponseFinalValues);
        m_iResponseValue = iValues[0];
        m_bUpdateResponse = true;
    }

    
    void UModbusTCPOnException(ushort _oID, byte _oUnit, byte _oFunction, byte _oException) {
        Debug.Log("Exception: " + _oException);
    }
}
