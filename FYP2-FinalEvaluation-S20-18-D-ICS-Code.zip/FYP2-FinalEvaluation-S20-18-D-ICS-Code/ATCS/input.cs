﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class input : MonoBehaviour
{
    public GameObject setPoint;
    public TextMeshPro inputFrequency;
    public Text panelFrequency;
    public Text panelPressure;
    public Text setPanelPressure;
    public TextMeshPro pressure;
    private float setPointPressure, currentPressure;
    public static float frequency;
    public static bool status  = false;
    public ParticleSystem FireworksAll;
    // Start is called before the first frame update
    void Start()
    {

    }
    // Update is called once per frame
    void Update()
    {
        pressure.text = (ExampleUModbusTCP.val[2]).ToString();
        inputFrequency.text = (ExampleUModbusTCP.val[6]).ToString();
        panelFrequency.text = "Motor Frequency: " + (ExampleUModbusTCP.val[6]).ToString();
        panelPressure.text = "Tank Pressure: " + (ExampleUModbusTCP.val[2]).ToString();
        setPanelPressure.text = "Tank P Set Point: " + (ExampleUModbusTCP.val[3]).ToString();

        if (ExampleUModbusTCP.val[2] > ExampleUModbusTCP.val[3]) { FireworksAll.Play(); }  

    }
}
