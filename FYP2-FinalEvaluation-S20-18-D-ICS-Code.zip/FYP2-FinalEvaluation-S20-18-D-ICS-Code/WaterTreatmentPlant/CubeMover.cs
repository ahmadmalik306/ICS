﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;	
public class CubeMover : MonoBehaviour
{	
	
	public float water = 0;
	private float d = 20;
	public bool isOn=false;
	//rotates the wheel of valves
	public void On(float d){
		transform.Rotate(0,d ,0);
	}
	//rotates the wheel of valves
	public void Off(float d){
		transform.Rotate(0,-d ,0);
	}
}
