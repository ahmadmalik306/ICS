﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
public class WaterInput1 : MonoBehaviour
{	
	float waterFlowRate=0.9333f;
	float water=0f;
	float maxWaterInTAnk=56f;
	float waterPercentForbar=0f;
	public Slider waterLevel; 
	public TextMeshProUGUI tempC;
	public float GetWaterLevel(){
		return water;
	}
	public float GetMaxWaterLevel(){
		return maxWaterInTAnk;	
	}
	public int CheckWaterLevel(){
		if(water>=maxWaterInTAnk)
				return 1;
		if (water<0)
				return 0;
		return -1;
	}
    void Start()
    {	
		waterLevel.value=0;
	}
	// starts the InvokeRepeating function whichthen calls the required function to add water in the tank after every given amount of seconds
	public void StartInv()
    {	
		InvokeRepeating ("Func", 1f, 1f);
    }
	// starts the InvokeRepeating function which then calls the required function to remove water in the tank after every given amount of seconds
	public void StartInvRem()
    {	
		InvokeRepeating ("RemoveWater", 1f, 1f);
    }
	//calls CancelInvoke to stop the already started InvokeRepeating function
	public void CancelRem(){
		 CancelInvoke("RemoveWater");
	}
	
	//calls CancelInvoke to stop the already started InvokeRepeating function
	public void Cancel(){
		 CancelInvoke("Func");
	}
	//function to add water in the tank
	public void Func(){
		water+=waterFlowRate;
		waterPercentForbar=(water/maxWaterInTAnk);
		tempC.text="Water = "+((int)water).ToString()+" L";
		waterLevel.value=waterPercentForbar;
	}
	//function to remove water from the tank
	public void RemoveWater(){
		if(water>0)
			water-=1;
		waterPercentForbar=(water/maxWaterInTAnk);
		tempC.text="Water = "+((int)water).ToString()+" L";
		waterLevel.value=waterPercentForbar;
	}
	void FixedUpdate(){
		//It turns on the motor if water level in the coagulation tank is low
		if(CheckWaterLevel()==0){
			GameObject.FindGameObjectWithTag("Motor").GetComponent<pumpWater>().SetIsOn(true);
		}
		else if (CheckWaterLevel()==-1){
			
		}
	}
}
