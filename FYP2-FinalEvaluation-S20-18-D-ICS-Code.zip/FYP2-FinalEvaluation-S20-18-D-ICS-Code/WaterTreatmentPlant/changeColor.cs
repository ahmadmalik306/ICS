﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class changeColor : MonoBehaviour
{
	public Renderer light;
	
	public bool on;
    // Start is called before the first frame update
    void Start()
    {
        light = gameObject.GetComponent<Renderer>(); 
    }

    // Update is called once per frame
    void Update()
    {
        
    }
	public void TurnOn(){
		light.material.color = new Color(0.2042253f,1,0,1); // light will turn green
		on=true;
	}
	public void TurnOff(){
		light.material.color = new Color(0.6980392f,0.04313726f,0.04313726f,1); // ligth will turn red
		on=false;
	}
}
