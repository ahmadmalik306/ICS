﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
public class filteration : MonoBehaviour
{
    float waterFlowRate=0.9333f;
	float water=0f;
	//float alum=7.5f;
	bool flag=true;
	public TextMeshProUGUI waterDisplay;
	public TextMeshProUGUI alumDisplay;
	public void Start(){
	}
	public float GetwaterLevel(){
		return water;
	}
	IEnumerator ExampleCoroutine()
    {
		yield return new WaitForSeconds(1f);
	}
	// starts the InvokeRepeating function whichthen calls the required function to add water in the tank after every given amount of seconds
	public void StartInv()
    {	
		InvokeRepeating ("Func1", 5f, 1f);
    }
	// starts the InvokeRepeating function which then calls the required function to remove water in the tank after every given amount of seconds
	public void StartInvRem()
    {	
		InvokeRepeating ("RemoveWater", 1f, 1f);
    }
	//calls CancelInvoke to stop the already started InvokeRepeating function
	public void CancelRem(){
		 CancelInvoke("RemoveWater");
	}
	//calls CancelInvoke to stop the already started InvokeRepeating function
	public void Cancel(){
		 CancelInvoke("Func1");
	}
	//function to add water in the tank
	public void Func1(){
		StartCoroutine(ExampleCoroutine());
		water+=1;
	}
	//function to remove water from the tank
	public void RemoveWater(){
		StartCoroutine(ExampleCoroutine());
		if(water>0)
			water-=waterFlowRate;
	}
	int x=0;
	void FixedUpdate(){
		//checks if the previous tank is full then turns on the valve for water input
        if (GameObject.FindGameObjectWithTag("sediment").GetComponent<CoagulationAndSedimentaton>().CheckWaterLevel())
        {
			if(flag==true){
				GameObject.FindGameObjectWithTag("valve2").GetComponent<changeColor>().TurnOn();
				GameObject.FindGameObjectWithTag("valver1").GetComponent<CubeMover>().On(10);
				StartInv();
				GameObject.FindGameObjectWithTag("sediment").GetComponent<CoagulationAndSedimentaton>().StartInvRem();
				flag=false;
			}
		}
		//checks if the previous tank is empty then turns off the valve for water input
		else if(GameObject.FindGameObjectWithTag("sediment").GetComponent<CoagulationAndSedimentaton>().water<0){
			if(!flag){
				Cancel();
				GameObject.FindGameObjectWithTag("valve2").GetComponent<changeColor>().TurnOff();
				GameObject.FindGameObjectWithTag("valver1").GetComponent<CubeMover>().Off(10);
				GameObject.FindGameObjectWithTag("sediment").GetComponent<CoagulationAndSedimentaton>().CancelRem();
				flag=true;
			}
		}
	}
}
