﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class CoagulationAndSedimentaton : MonoBehaviour
{
	
    float waterFlowRate=0.9333f;
	public float water=0f;
	float Alum=7.5f;
	float maxWaterInTAnk=70f;
	bool flag=true;
	public TextMeshProUGUI waterDisplay;
	public TextMeshProUGUI AlumDisplay;
	public void Start(){
		
	}
	public float GetWaterLevel(){
		return water;
	}
	IEnumerator ExampleCoroutine()
    {
		yield return new WaitForSeconds(1f);
	}
	public float GetMaxWaterLevel(){
		return maxWaterInTAnk;	
	}
	public bool CheckWaterLevel(){
        if ( water >= maxWaterInTAnk ) { return true; }
		return false;
	}
	// starts the InvokeRepeating function whichthen calls the required function to add water in the tank
	public void StartInv()
    {	
		InvokeRepeating ("Func1", 1f, 1f);
    }
	// starts the InvokeRepeating function which then calls the required function to remove water in the tank after every given amount of seconds
	public void StartInvRem()
    {	
		InvokeRepeating ("RemoveWater", 5f, 1f);
    }
	//calls CancelInvoke to stop the already started InvokeRepeating function
	public void CancelRem(){
		 CancelInvoke("RemoveWater");
	}
	//calls CancelInvoke to stop the already started InvokeRepeating function
	public void Cancel(){
		 CancelInvoke("Func1");
	}
	//function to add water in the tank
	public void Func1(){
		StartCoroutine(ExampleCoroutine());
		water+=1;
		waterDisplay.text="water = "+((int)water).ToString()+" L";
	}
	//function to remove water from the tank
	public void RemoveWater(){
		StartCoroutine(ExampleCoroutine());
		if(water>0)
			water-=waterFlowRate;
		waterDisplay.text="water = "+((int)water).ToString()+" L";
	}
	int x=0;
	void FixedUpdate(){
		//fills the tank with water if the wtank is not full and the motor is on  
		if(water<=0 && !GameObject.FindGameObjectWithTag("Motor").GetComponent<pumpWater>().GetIsOn()){
			x=x+1;
			if(flag==true){
				GameObject.FindGameObjectWithTag("valve1").GetComponent<changeColor>().TurnOn();
				GameObject.FindGameObjectWithTag("valver").GetComponent<CubeMover>().On(10);
				AlumDisplay.text="Alum = "+Alum*maxWaterInTAnk+" mg";
				StartInv();
				GameObject.FindGameObjectWithTag("coagTank").GetComponent<WaterInput1>().StartInvRem();
				flag=false;
			}
		}
		else if(CheckWaterLevel()){
			if(!flag){
				Cancel();
				GameObject.FindGameObjectWithTag("valve1").GetComponent<changeColor>().TurnOff();
				GameObject.FindGameObjectWithTag("valver").GetComponent<CubeMover>().Off(10);
				GameObject.FindGameObjectWithTag("coagTank").GetComponent<WaterInput1>().CancelRem();
				flag=true;
			}
		}
	}
}
