﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class chlorination : MonoBehaviour
{
    
    float waterFlowRate=0.9333f;
    float waterFlowOut=1.3432f;
	float water=0f;
	float chlorineRate=4f;
	float clConcWIn=0f;
	float clConcWOut=0f;
	float currentChlorineConcentration=0f;
	float chlorineConcentration=0f;
	bool flag=true;
	public TextMeshProUGUI waterDisplay;
	public TextMeshProUGUI chlorineDisplay;
	float maxWater=50f;
	public void Start(){
	}
	public float GetWaterLevel(){
		return water;
	}
	IEnumerator ExampleCoroutine()
    {
		yield return new WaitForSeconds(1f);
	}
	// starts the InvokeRepeating function which then calls the required function to add water in the tank after every given amount of seconds
	public void StartInv()
    {	
		InvokeRepeating ("Func1", 5f, 1f);
    }
	
	// starts the InvokeRepeating function whichthen calls the required function to add chlorine in the water after every given amount of seconds
	public void StartClAdd()
    {	
		InvokeRepeating ("ChlorineAdd", 5f, 1f);
    }
	// starts the InvokeRepeating function which then calls the required function to remove chlorine in the water after every given amount of seconds
	public void StartClRem()
    {	
		InvokeRepeating ("ChlorineRem", 10f, 1f);
    }
	// starts the InvokeRepeating function which then calls the required function to remove water in the tank after every given amount of seconds
	public void StartInvRem()
    {	
		InvokeRepeating ("RemoveWater", 10f, 1f);
    }
	//calls CancelInvoke to stop the already started InvokeRepeating function
	public void CancelRem(){
		 CancelInvoke("RemoveWater");
	}
	//calls CancelInvoke to stop the already started InvokeRepeating function
	public void Cancel(){
		 CancelInvoke("Func1");
	}
	//calls CancelInvoke to stop the already started InvokeRepeating function
	public void CancelClAdd(){
		 CancelInvoke("ChlorineAdd");
	}
	//calls CancelInvoke to stop the already started InvokeRepeating function
	public void CancelClRem(){
		 CancelInvoke("ChlorineRem");
	}
	//adds water and calls the StartClAdd function to add chlorine in the chlorination tank
	public void Func1(){
		//StartCoroutine(ExampleCoroutine());
		StartClAdd();
		GameObject.FindGameObjectWithTag("cvalve").GetComponent<changeColor>().TurnOn();
		GameObject.FindGameObjectWithTag("cvalver").GetComponent<CubeMover>().On(20);
		water+=waterFlowRate;
		waterDisplay.text="water = "+((int)water).ToString()+" L";
	}
	//Adds chlorine to the chlorination tank
	public void ChlorineAdd(){
		chlorineConcentration=chlorineConcentration+(chlorineRate*waterFlowRate);
		chlorineDisplay.text="Cl conc. = "+((int)chlorineConcentration).ToString()+" mg";
	}
	// displays the remainig chlorine concentration 
	public void ChlorineRem(){
		chlorineConcentration=chlorineConcentration-(chlorineRate*waterFlowRate);
		chlorineConcentration=currentChlorineConcentration;
		chlorineDisplay.text="Cl conc. = "+((int)chlorineConcentration).ToString()+" mg";
	}
	//Removes water from the tank 
	public void RemoveWater(){
		StartCoroutine(ExampleCoroutine());
		StartClRem();
		if(water>0)
			water-=waterFlowOut;
		waterDisplay.text="water = "+((int)water).ToString()+" L";
	}
	int x=0;
	void FixedUpdate(){
		if(GameObject.FindGameObjectWithTag("sediment").GetComponent<CoagulationAndSedimentaton>().CheckWaterLevel() ){
			if(flag==true){
				GameObject.FindGameObjectWithTag("valve3").GetComponent<changeColor>().TurnOn();
				GameObject.FindGameObjectWithTag("valver2").GetComponent<CubeMover>().On(20);
				GameObject.FindGameObjectWithTag("filter").GetComponent<filteration>().StartInvRem();
				StartInv();
				flag=false;
			}
		}
		else if( water>=maxWater ){
			if(!flag){
				Cancel();
				CancelClAdd();
				GameObject.FindGameObjectWithTag("valve3").GetComponent<changeColor>().TurnOff();
				GameObject.FindGameObjectWithTag("valver2").GetComponent<CubeMover>().Off(20);
				GameObject.FindGameObjectWithTag("valve2").GetComponent<changeColor>().TurnOff();
				GameObject.FindGameObjectWithTag("valver1").GetComponent<CubeMover>().Off(20);
				GameObject.FindGameObjectWithTag("sediment").GetComponent<CoagulationAndSedimentaton>().CancelRem();
				GameObject.FindGameObjectWithTag("filter").GetComponent<filteration>().CancelRem();
				GameObject.FindGameObjectWithTag("cvalve").GetComponent<changeColor>().TurnOff();
				GameObject.FindGameObjectWithTag("cvalver").GetComponent<CubeMover>().Off(20);
				StartInvRem();
				flag=true;
			}
		}
	}
}
