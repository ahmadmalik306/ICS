﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class pumpWater : MonoBehaviour
{
	[SerializeField]
	Vector3 v3Force2 = new Vector3(0,0.01f,0);
	bool on=true;
	bool invokeStarted=false;
	int x=1;
	//sets the state of motor to on or off
	public void SetIsOn(bool flag){
		 on=flag;
	}
	public bool GetIsOn(){
		return on;
	}
	IEnumerator ExampleCoroutine()
    {
			//motor movement after 0.1seconds to show motor is on 
			transform.position+=v3Force2;
			yield return new WaitForSeconds(0.1f);
			transform.position-=v3Force2;
			// turns off if water level in the coagulation tank is full
			if(GameObject.FindGameObjectWithTag("coagTank").GetComponent<WaterInput1>().CheckWaterLevel()==1){
				on=false;
			}
			
    }
    void FixedUpdate()
    {	
		if(on)
		{
			StartCoroutine(ExampleCoroutine());
			if(invokeStarted==false)
			{
				//Starts filling the coagulation tank
				GameObject.FindGameObjectWithTag("coagTank").GetComponent<WaterInput1>().StartInv();
				invokeStarted=true;
			}
		}
		else{
			//it means motor is turned off so it stops filling the water tank
			GameObject.FindGameObjectWithTag("coagTank").GetComponent<WaterInput1>().Cancel();
			invokeStarted=false;
		}
    }
}
